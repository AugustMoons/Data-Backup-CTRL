from collections.abc import Callable, Iterable, Mapping
import tkinter as tk
from typing import Any
from lib.functions.run import check,check0,zz,help,get_image,bug,runpy
import threading
from os import system
from lib.functions.autobk import main
import sqlite3
from time import sleep
from configparser import ConfigParser


#展示文件丢失页面
def diushi(a):
    diushi = tk.Tk()
    diushi.title('一些文件因一些不可控原因丢失')
    diushi.geometry('512x400')

    label = tk.Label(diushi,text=a,font=('宋体',12))
    label.pack()

    diushi.mainloop()

def such():#搜索数据库中已启动的任务
    db = sqlite3.connect('data.db')
    cur = db.cursor()
    cur.execute("SELECT * FROM task where status == '┗|｀O′|┛ 嗷~~'")
    db.commit()
    a = cur.fetchall()
    num = len(a)
    cur.close()
    db.close()
    return a,num

def on():
    global threads
    var.set('正在开启')
    cf = ConfigParser()
    cf.read('config.ini', encoding='utf-8')
    cf['auto-backup']['autobackup-status'] = 'True'
    with open('config.ini', 'w') as configfile:
        cf.write(configfile)
    threads = []
    try:
        lst,num = such()
        for i in lst:
            i = list(i)
            t = threading.Thread(target=main,args=i)
            threads.append(t)
        for i in range(len(threads)):
            sleep(0.1)
            threads[i].start()
    except:
        var.set('开启失败')
    var.set('已开启')

def off():
    cf = ConfigParser()
    cf.read('config.ini', encoding='utf-8')
    cf['auto-backup']['autobackup-status'] = 'False'
    with open('config.ini', 'w') as configfile:
        cf.write(configfile)
    var.set('已关闭')


window= tk.Tk()
window.title('Data-Backup-CTRL_2.0')
window.geometry('1024x728')
window.iconbitmap('lib/photo/widget/1.ico')

flag = True
threads = []


#设置menu栏
menu=tk.Menu(window)

bangzhu = tk.Menu(menu,tearoff=0)
bangzhu.add_command(label='使用说明',command=help,font=('黑体',8,'normal'))
menu.add_cascade(label='帮助',menu=bangzhu,font=('宋体',12,'normal'))

caozuo = tk.Menu(menu,tearoff=0)
caozuo.add_command(label='创建任务',command=lambda: runpy(r'lib/views/creative.py'),font=('宋体',8,'normal'))
caozuo.add_command(label='查询任务',command=lambda: runpy(r'lib/views/select.py'),font=('宋体',8,'normal'))
caozuo.add_command(label='编辑任务',command=lambda: runpy(r'lib/views/change.py'),font=('宋体',8,'normal'))
caozuo.add_command(label='删除任务',command=lambda: runpy(r'lib/views/drop.py'),font=('宋体',8,'normal'))
caozuo.add_command(label='手动备份',command=lambda: runpy(r'lib/views/backup.py'),font=('宋体',8,'normal'))
menu.add_cascade(label='操作',menu=caozuo,font=('宋体',12,'normal'))

zanzhu = tk.Menu(menu,tearoff=0)
zanzhu.add_command(label='赞助',command=zz,font=('宋体',8,'normal'))
menu.add_cascade(label='赞助',menu=zanzhu,font=('宋体',12,'normal'))
window.config(menu=menu)

#设置背景图片
canvas_root = tk.Canvas(window,width=1024,height=728)
im_root = get_image(check(),1024,728)
canvas_root.create_image(512,364,image = im_root)



#设置组件
im_label1 = get_image('lib/photo/widget/bt.png',1024,70)
label = tk.Label(window,image=im_label1)

var = tk.StringVar()
label2 = tk.Label(window,textvariable=var,font=('宋体',24),width=8,height=2)
var.set('已关闭')

im_on = get_image('lib/photo/widget/on.png',250,50)
button_on = tk.Button(window,image=im_on,compound=tk.CENTER,command=on)
im_off = get_image('lib/photo/widget/off.png',250,50)
button_off = tk.Button(window,image=im_off,compound=tk.CENTER,command=off)

im_button1 = get_image('lib/photo/widget/4.png',250,50)#赞助
button1 = tk.Button(window,image=im_button1,compound=tk.CENTER,command=zz)

im_button2 = get_image('lib/photo/widget/5.png',250,50)#bug反馈
button2 = tk.Button(window,image=im_button2,compound=tk.CENTER,command=bug)

a = check0()
im_button3 = get_image('lib/photo/widget/10.png',250,50)
button3 = tk.Button(window,image=im_button3,compound=tk.CENTER,command=lambda :diushi(a))

label.place(y=0)
label2.place(x=350,y=550)
button_off.place(x=700,y=450)
button_on.place(x=700,y=350)
canvas_root.pack()
button1.place(x=700,y=550)
button2.place(x=700,y=650)
if a != '所有必要文件已准备就绪':
    button3.place(x=500,y=400)

window.mainloop()              