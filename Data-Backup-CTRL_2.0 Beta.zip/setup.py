import setuptools


long_description ='''
# 声明：
    开源协议采用：Apache License2.0
    可商用，修改，分发，但必须注明作者来源和修改内容以及协议，侵权必究！
    
    第一个试行版本，如若发生错误或异常，可发信至此QQ邮箱2676796446@qq.com反馈问题，感谢您的反馈
    
    高中生的处女作，欢迎广大用户批评指正
    
    该版本以及后续版本都将免费开源，但请保留出处，给我在源码中留个名儿就行，非常感谢！
# 主要功能
> 对计算机数据定时自动完成备份打包，并且可限制备份数量以防止过量冗余，并且通过核心控制台，对数据库进行增删查改等操作，来创建查询修改启动关闭任务，每个任务可指定源数据包和目标路径还有备份数量，还可以通过核心控制台进行手动备份

'''

setuptools.setup(
    name='Data-Backup-CTRL',
    version='1.0',
    author='八月不落东方叶',
    author_email='2676796446@qq.com',
    description='数据自动备份管理控制系统',
    long_description=long_description,
    long_description_content_type='markdown',
    url='https://github.com/AugustMoons/Data-Backup-CTRL.git',
    include_package_data=True,
    package_data={
        'todo':['data/data.db']
    },
    packages=setuptools.find_packages(),
    classifiers=[
        'Programming Language :: Python :: 3',
        'Licence :: Apache License2.0',
    ],
    python_requires='>=3.6'

)