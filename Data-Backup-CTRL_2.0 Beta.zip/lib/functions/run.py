'''   Copyright [八月不落东方叶] [name of copyright owner]

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

     http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
'''

from os import listdir,system
import webbrowser
from PIL import Image,ImageTk
import random as r

#运行其他程序
def runpy(a):
    dire = a
    system('python %s' %dire)
#调整背景图大小
def get_image(filename,width,height):
    im = Image.open(filename).resize((width,height))
    return ImageTk.PhotoImage(im)
#打开帮助页（赞赏）
def help():
    webbrowser.open('https://blog.eastaug.top/archives/backup2-0.html',new=0,autoraise=True)
#打开赞助页
def zz():
    a = r.randint(0,2)
    if a == 0:
        webbrowser.open('https://pic.eastaug.top/LightPicture/2023/05/a1d49a464ed4b833.png',new=0,autoraise=True)
    elif a == 1:
        webbrowser.open('https://pic.eastaug.top/LightPicture/2023/05/7574af1a5b69751d.png',new=0,autoraise=True)
    else:
        webbrowser.open('https://pic.eastaug.top/LightPicture/2023/05/e181d33cb56eaffb.png',new=0,autoraise=True)
#打开bug反馈页
def bug():
    webbrowser.open('https://blog.eastaug.top/archives/91.html',new=0,autoraise=True)
#判断软件状态
a = ''
def check():
    global a
    if check0() == '所有必要文件已准备就绪':
        return 'lib/photo/bg/bg1.png'
    else:
        a = check0()
        return 'lib/photo/bg/bg2.png'

#检查文件丢失情况
def check0():#检查文件是否齐全
    func =[]
    lib = []
    views = []
    db = []
    photo = []
    bg = []
    temp = []
    widget = []
    t=''
    a = ''
    #检查lib路径
    lit = listdir('./') 
    lib_list = ['config.ini','data.db','版权声明.license']
    for i in lib_list:
        if i not in lit:
            lib.append(i)

    #检查lib/functions路径
    lit = listdir('lib/functions')
    func_lit = ['exec.py','run.py','sql.py','__init__.py','__pycache__','autobk.py']#todo/functions必要的文件
    for i in func_lit:
        if i not in lit:
            func.append(i)

    #检查lib/views路径
    lit = listdir('lib/views') 
    view_list = ['__init__.py','backup.py','change.py','changeonce.py','changestatus.py','creative.py','drop.py','main.py','select.py']
    for i in view_list:
        if i not in lit:
            views.append(i)

    #检查lib/data路径
    lit = listdir('lib/data') 
    db_list = ['data.db']
    for i in db_list:
        if i not in lit:
            db.append(i)

    #检查lib/photo路径
    lit = listdir('lib/photo') 
    photo_list = ['bg', 'temp', 'widget']
    for i in photo_list:
        if i not in lit:
            photo.append(i)

    #检查lib/photo/bg路径
    lit = listdir('lib/photo/bg') 
    photo_list = ['backup.png', 'bg1.png', 'bg2.png', 'bingo.png', 'change.png', 'changeonce.png', 'changestatus.png', 'cre.png', 'drop.png', 'sel.png']
    for i in photo_list:
        if i not in lit:
            bg.append(i)

    #检查lib/photo/widget路径
    lit = listdir('lib/photo/widget') 
    wid_list = ['10.png', '4.png', '5.png', 'bt.png', 'cx.png', 'off.png', 'on.png', 'qd.png', 'yesorno.png', '修改状态.png', '关闭所有任务.png', '单一任务.png', '打开所有任务.png', '按钮图标.png', '查询.png']
    for i in wid_list:
        if i not in lit:
            widget.append(i)

    if func == [] and lib == [] and views == [] and db == [] and photo == [] and bg == [] and temp == [] and widget == []:
        return '所有必要文件已准备就绪'
    else:
        if func != []:
            j=0
            for i in func:
                j+=1
                t += (str(j)+'.     '+str(i)+'\n')
            a ='在软件目录lib/functions下，丢失以下文件：\n\n'+t
            t = ''

        if lib != []:
            j=0
            for i in lib:
                j+=1
                t+= (str(j)+'.     '+str(i)+'\n')
            a =a+'\n\n在软件目录lib/下，丢失以下文件：\n\n'+t
            t = ''

        if views != []:
            j=0
            for i in views:
                j+=1
                t+= (str(j)+'.     '+str(i)+'\n')
            a =a+'\n\n在软件目录lib/views下，丢失以下文件：\n\n'+t
            t = ''

        if db != []:
            j=0
            for i in db:
                j+=1
                t+= (str(j)+'.     '+str(i)+'\n')
            a =a+'\n\n在软件目录lib/data下，丢失以下文件：\n\n'+t
            t = ''

        if photo != []:
            j=0
            for i in photo:
                j+=1
                t+= (str(j)+'.     '+str(i)+'\n')
            a =a+'\n\n在软件目录lib/photo下，丢失以下文件：\n\n'+t
            t = ''

        if bg != []:
            j=0
            for i in bg:
                j+=1
                t+= (str(j)+'.     '+str(i)+'\n')
            a =a+'\n\n在软件目录lib/photo/bg下，丢失以下文件：\n\n'+t
            t = ''
    
        if temp != []:
            j=0
            for i in temp:
                j+=1
                t+= (str(j)+'.     '+str(i)+'\n')
            a =a+'\n\n在软件目录lib/photo/temp下，丢失以下文件：\n\n'+t
            t = ''

        if widget != []:
            j=0
            for i in widget:
                j+=1
                t+= (str(j)+'.     '+str(i)+'\n')
            a =a+'\n\n在软件目录lib/photo/widget下，丢失以下文件：\n\n'+t
            t = ''

        return a
#跳转到查询任务
