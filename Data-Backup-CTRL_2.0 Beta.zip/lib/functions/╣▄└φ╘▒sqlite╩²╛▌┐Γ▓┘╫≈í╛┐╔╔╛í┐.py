'''   Copyright [八月不落东方叶] [name of copyright owner]

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

     http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
'''


import sqlite3

conn = sqlite3.connect('data.db')
cur = conn.cursor()

#插入任务语句
insert = "INSERT INTO task VALUES (?,?,?,?,?,?)"
#插入的初始任务模板语句
id=3
name='小白'
old_path='C:\\Users\\AUGUST-MOONS\\Desktop\\data_exec\\新建文件夹'
new_path='D:\\python程序文件\\项目\\数据定时备份\\新建文件夹'
retain_num=2
status=1
#创建表语句————task
cre = '''CREATE TABLE IF NOT EXISTS task(
    id INT, 
    name TEXT, 
    old_path TEXT, 
    new_path TEXT,  
    retain_num TEXT, 
    status TEXT 
    )'''
cre2 = '''CREATE TABLE IF NOT EXISTS backup(
    id INT, 
    name TEXT, 
    bkplastnum TEXT 
    )'''
#删除语句
dele = "DELETE FROM task where id ==3"
#查询表语句
s = "SELECT * FROM task"#查所有行
"SELECT * FROM task where status == '┗|｀O′|┛ 嗷~~'"#查开启状态数据行
#更新数据语句
up = "UPDATE task SET new_path = 'D:\\测试'"
#删除数据语句
drop = "drop table if exists task"

cur.execute()
#插入执行参数请填入：insert,(id,name,old_path,new_path,retain_num,status)
conn.commit()
print(cur.fetchall())
cur.close()
conn.close()