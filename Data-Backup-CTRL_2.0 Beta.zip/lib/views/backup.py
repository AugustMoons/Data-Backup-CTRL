import tkinter as tk
from PIL import Image,ImageTk
from pathlib import PureWindowsPath
from time import localtime,time
import os
import zipfile

#备份功能函数
def crezip(dirpath, outFullName):
    """
    :param dirpath: 目标文件夹路径
    :param outFullName: 压缩文件保存路径+xxxx.zip 
    """
    zip = zipfile.ZipFile(outFullName, "w", zipfile.ZIP_DEFLATED)
    for path, dirnames, filenames in os.walk(dirpath):
        fpath = path.replace(dirpath, '')
        for filename in filenames:
            zip.write(os.path.join(path, filename), os.path.join(fpath, filename))
    zip.close()


#获取图片
def get_image(filename,width,height):
    im = Image.open(filename).resize((width,height))
    return ImageTk.PhotoImage(im)
#手动备份
def backup():
    input_path = E_oldpath.get()
    output_path = E_newpath.get()
    name = E_name.get()
    input_path = PureWindowsPath(input_path)
    input_path = input_path.as_posix()
    output_path = PureWindowsPath(output_path)
    output_path = output_path.as_posix()
    output_path = output_path + '/[手动备份]%s.zip'%name
    crezip(input_path, output_path)
    Backup.destroy()
    jieguoout()

#显示操作结果
def jieguoout():
    jieguo = tk.Tk()
    jieguo.title("操作成功")
    jieguo.iconbitmap('lib/photo/widget/1.ico')
    # 获取屏幕宽度和高度
    screen_width = jieguo.winfo_screenwidth()
    screen_height = jieguo.winfo_screenheight()
    # 计算窗体左上角坐标并设置位置
    x = (screen_width - 300) // 2
    y = (screen_height - 100) // 2
    jieguo.geometry("300x100+{}+{}".format(x, y))
    # 创建标签
    label = tk.Label(jieguo, text="操作成功", font=("Arial", 20))
    label.pack(pady=20)
    # 显示窗体
    jieguo.mainloop()

Backup= tk.Tk()
Backup.title('创建任务')
Backup.geometry('512x364')
Backup.iconbitmap('lib/photo/widget/1.ico')
v = tk.IntVar()
#设置背景
canvas_root = tk.Canvas(Backup,width=512,height=364)
im_root = get_image('lib/photo/bg/backup.png',512,364)
canvas_root.create_image(256,182,image = im_root)
#输入组件
E_oldpath = tk.Entry(bg='white',bd=1,cursor='arrow',font='宋体',fg='black',width=50,exportselection=0,highlightcolor='blue',textvariable='请输入源路径',xscrollcommand=1)
E_newpath = tk.Entry(bg='white',bd=1,cursor='arrow',font='宋体',fg='black',width=50,exportselection=0,highlightcolor='blue',textvariable='请输入目标路径',xscrollcommand=1)
E_name = tk.Entry(bg='white',bd=1,cursor='arrow',font='宋体',fg='black',width=20,exportselection=0,highlightcolor='blue',textvariable='请输入文件名',xscrollcommand=1)
image1 = get_image('lib/photo/widget/qd.png',95,35)
button = tk.Button(image=image1,compound=tk.CENTER,command=backup)
#组件布局
canvas_root.pack()
E_oldpath.place(x=30,y=60)
E_newpath.place(x=30,y=150)
E_name.place(x=30,y=250)
button.place(x=370,y=300)

Backup.mainloop()