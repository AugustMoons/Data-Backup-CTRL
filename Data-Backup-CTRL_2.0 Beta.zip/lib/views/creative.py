import tkinter as tk
from PIL import Image,ImageTk
from random import randint as r
import sqlite3


#显示操作结果
def jieguoout():
    jieguo = tk.Tk()
    jieguo.title("操作成功")
    jieguo.iconbitmap('lib/photo/widget/1.ico')
    # 获取屏幕宽度和高度
    screen_width = jieguo.winfo_screenwidth()
    screen_height = jieguo.winfo_screenheight()
    # 计算窗体左上角坐标并设置位置
    x = (screen_width - 300) // 2
    y = (screen_height - 100) // 2
    jieguo.geometry("300x100+{}+{}".format(x, y))
    # 创建标签
    label = tk.Label(jieguo, text="操作成功", font=("Arial", 20))
    label.pack(pady=20)
    # 显示窗体
    jieguo.mainloop()
#获取图片
def get_image(filename,width,height):
    im = Image.open(filename).resize((width,height))
    return ImageTk.PhotoImage(im)
#获取newid
def newid():                                                         #给新任务用户分配ID（数据库内按递增顺序，ID为缺失的第一项，返回ID
    sel = "SELECT id FROM task"
    db = sqlite3.connect('data.db')
    cur = db.cursor()
    cur.execute(sel)
    db.commit()
    a=cur.fetchall()
    cur.close()
    db.close()
    if len(a) == 0:
        return 1
    c=[]
    for i in a:
        i=i[0]
        c.append(i)
    c.sort()
    flag = True
    for i in range(len(c)):
        if c[i]!=1 and flag == True:
            d=1
            flag = False
            break
        elif i!=0:
            if c[i-1]+1 != c[i]:
                flag = False
                d=c[i-1]+1
                break
        else:
            flag = False
            d=c[-1]+1
    return d
#创建到数据库
def creative1():                                                  #向数据库注入新任务（输入参数为列表，包含所有字段）
    ins = "INSERT INTO task VALUES(?,?,?,?,?,?)"
    id = str(newid())
    name = E_name.get()
    old_path = E_oldpath.get()
    new_path = E_newpath.get()
    retain_num = E_retainnum.get()
    status = v.get()
    if retain_num == '':
        retain_num = 2
    if status == 1:
        status = '┗|｀O′|┛ 嗷~~'
    elif status == 0:
        status = '-------------'
    print(id,name,old_path,new_path,retain_num,status)
    if True:
        db = sqlite3.connect('data.db')
        cur = db.cursor()
        cur.execute(ins,(id,name,old_path,new_path,retain_num,status))
        db.commit()
        cur.execute("INSERT INTO backup VALUES(?,?,?)",(id,name,'0'))
        db.commit()
        cur.close()
        db.close()
        creative.destroy()
        jieguoout()
        return


creative= tk.Tk()
creative.title('创建任务')
creative.geometry('512x364')
creative.iconbitmap('lib/photo/widget/1.ico')
v = tk.IntVar()
#设置背景
canvas_root = tk.Canvas(creative,width=512,height=364)
im_root = get_image('lib/photo/bg/cre.png',512,364)
canvas_root.create_image(256,182,image = im_root)
#输入组件
label_id = tk.Label(creative,text='%d' %newid(),bg='white',font=('宋体',15),width=1,height=1)
E_name = tk.Entry(bg='white',bd=1,cursor='arrow',font='宋体',fg='black',width=15,exportselection=0,highlightcolor='blue',textvariable='请输入用户名',xscrollcommand=1)
E_oldpath = tk.Entry(bg='white',bd=1,cursor='arrow',font='宋体',fg='black',width=40,exportselection=0,highlightcolor='blue',textvariable='请输入源路径',xscrollcommand=1)
E_newpath = tk.Entry(bg='white',bd=1,cursor='arrow',font='宋体',fg='black',width=40,exportselection=0,highlightcolor='blue',textvariable='请输入目标路径',xscrollcommand=1)
E_retainnum = tk.Entry(bg='white',bd=1,cursor='arrow',font='宋体',fg='black',width=5,exportselection=0,highlightcolor='blue',textvariable='请输入保留备份包数量',xscrollcommand=1)
status_1 = tk.Radiobutton(creative,text='即刻开启',font=('宋体',8),variable=v,value=1)
status_2 = tk.Radiobutton(creative,text='稍后开启',font=('宋体',8),variable=v,value=0)
image1 = get_image('lib/photo/widget/qd.png',95,35)
button = tk.Button(image=image1,compound=tk.CENTER,command=creative1)
#组件布局
canvas_root.pack()
label_id.place(x=200,y=13)
E_name.place(x=20,y=80)
E_oldpath.place(x=20,y=148)
E_newpath.place(x=20,y=220)
E_retainnum.place(x=20,y=290)
status_1.place(x=20,y=325)
status_2.place(x=110,y=325)
button.place(x=400,y=320)

creative.mainloop()