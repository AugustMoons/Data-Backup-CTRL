import tkinter as tk
from PIL import Image,ImageTk
import sqlite3
#显示操作结果
def jieguoout():
    jieguo = tk.Tk()
    jieguo.title("操作成功")
    jieguo.iconbitmap('lib/photo/widget/1.ico')
    # 获取屏幕宽度和高度
    screen_width = jieguo.winfo_screenwidth()
    screen_height = jieguo.winfo_screenheight()
    # 计算窗体左上角坐标并设置位置
    x = (screen_width - 300) // 2
    y = (screen_height - 100) // 2
    jieguo.geometry("300x100+{}+{}".format(x, y))
    # 创建标签
    label = tk.Label(jieguo, text="操作成功", font=("Arial", 20))
    label.pack(pady=20)
    # 显示窗体
    jieguo.mainloop()
#获取图片
def get_image(filename,width,height):
    im = Image.open(filename).resize((width,height))
    return ImageTk.PhotoImage(im)
#修改内容
def write():
    id=entry1.get()
    name=entry2.get()
    old_path=entry3.get()
    new_path=entry4.get()
    retain_num=entry5.get()
    status = v.get()
    if status == 1:
        status = '┗|｀O′|┛ 嗷~~'
    elif status == 0:
        status = '-------------'
    a={'name':name,'old_path':old_path,'new_path':new_path,'retain_num':retain_num,'status':status}
    b={}
    for i in a.keys():
            if not a[i] == '':
                b[i]=a[i]
    keys = list(b.keys())
    values = list(b.values())
    up1 = "UPDATE task SET "
    up2 = 'where id == '
    c=''
    for i in range(len(keys)):
            c += str(keys[i])+' = '+"'"+str(values[i])+"',"
    db = sqlite3.connect('data.db')
    cur = db.cursor()
    up = up1+c[:len(c)-1]+' '+up2+id
    cur.execute(up)
    db.commit()
    cur.close()
    db.close()
    change2.destroy()
    jieguoout()

change2 = tk.Tk()
change2.title('修改单一状态')
change2.geometry('512x364')
change2.iconbitmap('lib/photo/widget/1.ico')
#设置背景
bg2 = tk.Canvas(change2,width=512,height=364)
im_root = get_image('lib/photo/bg/changeonce.png',512,364)
bg2.create_image(256,182,image = im_root)
#组件
v = tk.IntVar()
entry1 = tk.Entry(bg='white',bd=1,cursor='arrow',font='宋体',fg='black',width=5,exportselection=0,highlightcolor='blue',textvariable='id',xscrollcommand=1)
entry2 = tk.Entry(bg='white',bd=1,cursor='arrow',font='宋体',fg='black',width=15,exportselection=0,highlightcolor='blue',textvariable='name',xscrollcommand=1)
entry3 = tk.Entry(bg='white',bd=1,cursor='arrow',font='宋体',fg='black',width=40,exportselection=0,highlightcolor='blue',textvariable='old_path',xscrollcommand=1)
entry4 = tk.Entry(bg='white',bd=1,cursor='arrow',font='宋体',fg='black',width=40,exportselection=0,highlightcolor='blue',textvariable='new_path',xscrollcommand=1)
entry5 = tk.Entry(bg='white',bd=1,cursor='arrow',font='宋体',fg='black',width=5,exportselection=0,highlightcolor='blue',textvariable='retain_num',xscrollcommand=1)
status_1 = tk.Radiobutton(change2,text='即刻开启',font=('宋体',8),variable=v,value=1)
status_2 = tk.Radiobutton(change2,text='稍后开启',font=('宋体',8),variable=v,value=0)
image1 = get_image('lib/photo/widget/qd.png',95,35)
button = tk.Button(image=image1,compound=tk.CENTER,command=write)
#布局
bg2.pack()
entry1.place(x=18,y=65)
entry2.place(x=18,y=110)
entry3.place(x=18,y=165)
entry4.place(x=18,y=220)
entry5.place(x=18,y=270)
status_1.place(x=18,y=320)
status_2.place(x=100,y=320)
button.place(x=390,y=300)

change2.mainloop()