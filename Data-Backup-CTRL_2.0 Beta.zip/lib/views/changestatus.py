from PIL import Image,ImageTk
import tkinter as tk
import sqlite3

#显示操作结果
def jieguoout():
    jieguo = tk.Tk()
    jieguo.title("操作成功")
    jieguo.iconbitmap('lib/photo/widget/1.ico')
    # 获取屏幕宽度和高度
    screen_width = jieguo.winfo_screenwidth()
    screen_height = jieguo.winfo_screenheight()
    # 计算窗体左上角坐标并设置位置
    x = (screen_width - 300) // 2
    y = (screen_height - 100) // 2
    jieguo.geometry("300x100+{}+{}".format(x, y))
    # 创建标签
    label = tk.Label(jieguo, text="操作成功", font=("Arial", 20))
    label.pack(pady=20)
    # 显示窗体
    jieguo.mainloop()

#获取图片
def get_image(filename,width,height):
    im = Image.open(filename).resize((width,height))
    return ImageTk.PhotoImage(im)
#关闭所有任务
def off():
    db = sqlite3.connect('data.db')
    cur = db.cursor()
    cur.execute("UPDATE task SET status='-------------'")
    db.commit()
    cur.close()
    db.close()
    change1.destroy()
    jieguoout()
#打开所有任务
def on():
    db = sqlite3.connect('data.db')
    cur = db.cursor()
    cur.execute("UPDATE task SET status='┗|｀O′|┛ 嗷~~'")
    db.commit()
    cur.close()
    db.close()
    change1.destroy()
    jieguoout()

change1 = tk.Tk()
change1.title('修改全体状态')
change1.geometry('512x364')
change1.iconbitmap('lib/photo/widget/1.ico')
#设置背景
bg1 = tk.Canvas(change1,width=512,height=364)
im_root = get_image('lib/photo/bg/changestatus.png',512,364)
bg1.create_image(256,182,image = im_root)
#组件
image4 = get_image('lib/photo/widget/关闭所有任务.png',45,115)
image5 = get_image('lib/photo/widget/打开所有任务.png',45,115)
Button_4 = tk.Button(image=image4,compound=tk.CENTER,command=off)
Button_5 = tk.Button(image=image5,compound=tk.CENTER,command=on)
#布局
bg1.pack()
Button_4.place(x=20,y=100)
Button_5.place(x=440,y=100)

change1.mainloop()