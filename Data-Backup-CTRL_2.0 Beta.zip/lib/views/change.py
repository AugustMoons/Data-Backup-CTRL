import tkinter as tk
from tkinter import ttk
from PIL import Image,ImageTk
from random import randint as r
import sqlite3
from os import system

#获取图片
def get_image(filename,width,height):
    im = Image.open(filename).resize((width,height))
    return ImageTk.PhotoImage(im)


#运行其他程序
def runpy(a):
    dire = a
    system('python %s' %dire)
    
if __name__ == '__main__':
    cagchus = tk.Tk()
    cagchus.title('修改任务')
    cagchus.geometry('512x364')
    cagchus.iconbitmap('lib/photo/widget/1.ico')
    #设置背景
    bg = tk.Canvas(cagchus,width=512,height=364)
    im_root = get_image('lib/photo/bg/change.png',512,364)
    bg.create_image(256,182,image = im_root)
    #组件
    image1 = get_image('lib/photo/widget/查询.png',95,35)
    Button_1 = tk.Button(image=image1,compound=tk.CENTER,command=lambda :runpy(r'lib/views/select.py'))
    image2 = get_image('lib/photo/widget/修改状态.png',95,35)
    Button_2 = tk.Button(image=image2,compound=tk.CENTER,command=lambda :runpy(r'lib/views/changestatus.py'))
    image3 = get_image('lib/photo/widget/单一任务.png',95,35)
    Button_3 = tk.Button(image=image3,compound=tk.CENTER,command=lambda :runpy(r'lib/views/changeonce.py'))

    #组件布局
    bg.pack()
    Button_1.place(x=30,y=300)
    Button_2.place(x=130,y=300)
    Button_3.place(x=230,y=300)
    
    cagchus.mainloop()
