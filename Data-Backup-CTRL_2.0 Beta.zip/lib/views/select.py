import tkinter as tk
from tkinter import ttk
from PIL import Image,ImageTk
from random import randint as r
import sqlite3
#获取图片
def get_image(filename,width,height):
    im = Image.open(filename).resize((width,height))
    return ImageTk.PhotoImage(im)
#冒泡排序
def sort2(a):
    for i in range(len(a)):
        for j in range(i, len(a)):
            if a[i] > a[j]:
                a[i], a[j] = a[j], a[i]
            if len(a)>=2:
                if a[-1] < a[-2]:
                    a[-1],a[-2]=a[-2],a[-1]
    return a
#数据查询
def select1(): 
    b = E_select.get()
    try:                                                       #数据查询(输入参数统一为用户名或ID，空值为查询所有)
        db = sqlite3.connect('data.db')
        cur = db.cursor()
        if b == "":
            sel = "SELECT * FROM task"
            cur.execute(sel)
        else:
            sel = "SELECT * FROM task where id == ? or name == ?"
            cur.execute(sel,(b,b))  
        db.commit()
        a=cur.fetchall()
        if len(a) > 1:
            a=sort2(a)
        elif len(a)==0:
            a = [['无数据','无数据','无数据','无数据','无数据','无数据']]
        cur.close()
        db.close()
        a.insert(0,['ID','name','old_path','new_path','retain_num','status'])
        a.insert(1,['','','','','',''])
        output(a)
        return print('查询结束')
    except:
        print('查询错误error!')
        return 0

#显示结果新窗体
def output(out):
    tkouput = tk.Tk()
    tkouput.title('查询结果')
    tkouput.geometry('1024x728')
    tkouput.iconbitmap('lib/photo/widget/1.ico')
    columns = ['id INT', 'name TEXT', 'old_path TEXT', 'new_path TEXT',  'retain_num INT', 'status TEXT']
    
    scrollBar1 = tk.Scrollbar(tkouput,orient='vertical')
    treeview = ttk.Treeview(tkouput,height=31,show='headings',columns=columns,yscrollcommand=scrollBar1.set)

    for col in columns:
        treeview.column(col,width=80,anchor='w')   #每一行的宽度,'w'意思为靠右
    for i in out:
        treeview.insert('','end',values=i)

    scrollBar1.config(command=treeview.yview)
    scrollBar1.pack(side='right',fill='y')    
    treeview.pack(fill='x')
    tkouput.mainloop()


creative= tk.Tk()
creative.title('查询任务')
creative.geometry('512x364')
creative.iconbitmap('lib/photo/widget/1.ico')
v = tk.IntVar()
#设置背景
canvas_root = tk.Canvas(creative,width=512,height=364)
im_root = get_image('lib/photo/bg/sel.png',512,364)
canvas_root.create_image(256,182,image = im_root)
#输入组件
E_select = tk.Entry(bg='white',bd=1,cursor='arrow',font='宋体',fg='black',width=15,exportselection=0,highlightcolor='blue',textvariable='请输入查询用户ID或者用户名(请勿同时输入)',xscrollcommand=1)
image1 = get_image('lib/photo/widget/qd.png',95,35)
button = tk.Button(image=image1,compound=tk.CENTER,command=select1)
#组件布局
canvas_root.pack()
E_select.place(x=35,y=140)
button.place(x=350,y=250)

creative.mainloop()