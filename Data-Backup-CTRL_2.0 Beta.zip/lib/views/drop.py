import tkinter as tk
from PIL import Image,ImageTk
import sqlite3

#最终确认
def bingo():
    global bingo1
    bingo1 = tk.Tk()
    bingo1.title('最终确认')
    bingo1.geometry('512x364')
    
    #设置组件
    labelimg1 = tk.Label(bingo1, text='查询到以下任务，请确认',font=("Arial", 20))
    labelimg2 = tk.Label(bingo1, text='请确认是非为您想删除的任务',font=("Arial", 20))
    label1 = tk.Label(bingo1, text=sel(), font=("Arial", 10))
    image1 = get_image('lib/photo/widget/qd.png',95,35)
    button1 = tk.Button(bingo1,text='确定',compound=tk.CENTER,command=delete)
    #布局
    labelimg1.place(x=30,y=30)
    labelimg2.place(x=80,y=200)
    label1.place(x=10,y=130)
    button1.place(x=400,y=300)

    bingo1.mainloop()

#查找对应任务
def sel():
    id = entry1.get()
    name = entry2.get()
    if id == '' and name !='':
        sele = "SELECT * FROM task where name == '"+name+"'"
    elif name == '' and id !='':
        sele = "SELECT * FROM task where id == "+id
    elif id =='' and name == '':
        return '您未输入任何内容'
    else:
        sele = "SELECT * FROM task where id == "+id+" or name == '"+name+"'"
    db = sqlite3.connect('data.db')
    cur = db.cursor()
    cur.execute(sele)
    db.commit()
    out = cur.fetchall()
    cur.close()
    db.close()
    if len(out)>1:
        return '查询到多个任务，请确认数据正确性后重试'
    out = str(out)
    out = out[2:len(out)-2]
    return out
#显示操作结果
def jieguoout():
    jieguo = tk.Tk()
    jieguo.title("操作成功")
    jieguo.iconbitmap('lib/photo/widget/1.ico')
    # 获取屏幕宽度和高度
    screen_width = jieguo.winfo_screenwidth()
    screen_height = jieguo.winfo_screenheight()
    # 计算窗体左上角坐标并设置位置
    x = (screen_width - 300) // 2
    y = (screen_height - 100) // 2
    jieguo.geometry("300x100+{}+{}".format(x, y))
    # 创建标签
    label = tk.Label(jieguo, text="操作成功", font=("Arial", 20))
    label.pack(pady=20)
    # 显示窗体
    jieguo.mainloop()
#获取图片
def get_image(filename,width,height):
    im = Image.open(filename).resize((width,height))
    return ImageTk.PhotoImage(im)
#执行删除
def delete():
    id = entry1.get()
    name = entry2.get()
    if id == '' and name !='':
        dele1 = "DELETE FROM task where name == '"+name+"'"
    elif name == '' and id !='':
        dele1 = "DELETE FROM task where id =="+id
    elif id =='' and name == '':
        return
    else:
        dele1 = "DELETE FROM task where id =="+id+" or name == '"+name+"'"
    if id == '' and name !='':
        dele2 = "DELETE FROM backup where name == '"+name+"'"
    elif name == '' and id !='':
        dele2 = "DELETE FROM backup where id =="+id
    elif id =='' and name == '':
        return
    else:
        dele2 = "DELETE FROM backup where id =="+id+" or name == '"+name+"'"
    db = sqlite3.connect('data.db')
    cur = db.cursor()
    cur.execute(dele1)
    db.commit()
    cur.execute(dele2)
    db.commit()
    cur.close()
    db.close()
    bingo1.destroy()
    drop.destroy()
    jieguoout()


drop = tk.Tk()
drop.title('删除任务')
drop.geometry('512x364')
drop.iconbitmap('lib/photo/widget/1.ico')
#设置背景
bg2 = tk.Canvas(drop,width=512,height=364)
im_root = get_image('lib/photo/bg/drop.png',512,364)
bg2.create_image(256,182,image = im_root)
#设置组件
entry1 = tk.Entry(bg='white',bd=1,cursor='arrow',font='宋体',fg='black',width=5,exportselection=0,highlightcolor='blue',textvariable='id',xscrollcommand=1)
entry2 = tk.Entry(bg='white',bd=1,cursor='arrow',font='宋体',fg='black',width=15,exportselection=0,highlightcolor='blue',textvariable='name',xscrollcommand=1)
image1 = get_image('lib/photo/widget/qd.png',95,35)
button = tk.Button(image=image1,compound=tk.CENTER,command=bingo)
#布局
bg2.pack()
entry1.place(x=50,y=150)
entry2.place(x=50,y=250)
button.place(x=380,y=300)

drop.mainloop()