import tkinter as tk

class Application(tk.Frame):
    def __init__(self, master=None):
        super().__init__(master)
        self.master = master
        self.pack()
        self.create_widgets()

    def create_widgets(self):
        self.input1 = tk.Entry(self)
        self.input1.pack()

        self.input2 = tk.Entry(self)
        self.input2.pack()

        self.input3 = tk.Entry(self)
        self.input3.pack()

        self.submit = tk.Button(self)
        self.submit["text"] = "提交"
        self.submit["command"] = self.submit_callback
        self.submit.pack()

        self.result = tk.Label(self, textvariable=tk.StringVar(),background='red')
        self.result.pack()

    def submit_callback(self):
        content = [self.input1.get(), self.input2.get(), self.input3.get()]
        result = ', '.join(content)
        self.result.config(textvariable=result)

root = tk.Tk()
app = Application(master=root)
app.mainloop()
