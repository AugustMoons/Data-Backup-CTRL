from os import listdir
lit = listdir('./') 
print(lit)